package test.java.ca.viu.csci331.instruction.persistence.admission;

public class TestPersistenceOfAdmission
{

}
