Assignment 4: Business Objects in Java Application

New stuff:

Added Room class in model;

Added Rooms class in model;

Added difference check in add in Schedules class in model;

Added checkRoom in Schedules class in model;

Added Room class support for Schedule class in model;

Added setC, setIns, addSch, rremoveSch, checkSch to Seminars class in model;

Added setIns, setC, getCap, showSch, checkSch to Seminar class in model;

Added difference check for addValidSchedule in Seminar class in model;

Added Administration class in main/…/services/administration;

Added TestAdministration class to test/…/services/administration;
