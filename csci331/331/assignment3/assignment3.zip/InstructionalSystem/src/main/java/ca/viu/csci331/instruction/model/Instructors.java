package main.java.ca.viu.csci331.instruction.model;

import java.util.*;

public class Instructors
{
	private LinkedList <Instructor> instructors = new LinkedList <Instructor> ();
	private final int capacity;
	private int numberOfInstructors;
	
	public Instructors(int cap)
	{
		capacity = cap;
		numberOfInstructors = 0;
	}
	
	public void hire(Instructor newI)
	{
		if (numberOfInstructors == capacity)
		{
			System.out.println("Error: Instructors database is at it's capacity, please try again later\n");
		}
		else
		{
			instructors.add(newI);
			numberOfInstructors++;
		}
	}
	
	public void terminate(Instructor i)
	{
		if (instructors.contains(i))
		{
			int j = instructors.indexOf(i);
			instructors.remove(j);
			numberOfInstructors--;
		}
		else
		{
			System.out.println("Error: no such instructor found. Please check your data and try again\n");
		}
	}
	
	public void show()
	{
		Instructor temp = new Instructor();
		System.out.println("All hired instructors:\n");
		for (int i = 0; i < numberOfInstructors; i++)
		{
			temp = instructors.get(i);
			System.out.print(i);
			System.out.println(":");
			temp.show();
		}
	}
	
	public Instructor searchByName(String n)
	{
		Instructor temp = new Instructor();
		for (int i = 0; i < numberOfInstructors; i++)
		{
			temp = instructors.get(i);
			if (temp.getName() == n)
			{
				return temp;
			}
		}
		temp = new Instructor();
		temp.setName("No such Instructor found");
		return temp;
	}
	
	public Instructor searchByID(String id)
	{
		Instructor temp = new Instructor();
		for (int i = 0; i < numberOfInstructors; i++)
		{
			temp = instructors.get(i);
			if (temp.getID() == id)
			{
				return temp;
			}
		}
		temp = new Instructor();
		temp.setName("No such Instructor found");
		return temp;
	}
}
