package main.java.ca.viu.csci331.instruction.model;

public class Instructor
{
	private String name = new String();
	private String insID = new String();
	private String email = new String();
	
	public Instructor()
	{
	}
	
	public Instructor(String n, String id, String mail)
	{
		name = n;
		insID = id;
		email = mail;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getID()
	{
		return insID;
	}
	
	public String getEmail()
	{
		return email;
	}
	
	public void setName(String newName)
	{
		name = newName;
	}

	public void setID(String newID)
	{
		insID = newID;
	}
	
	public void setEmail(String newEmail)
	{
		email = newEmail;
	}
	
	public void show()
	{
		System.out.print("Instructor's name: ");
		System.out.println(name);
		System.out.print("Instructor's ID: ");
		System.out.println(insID);
		System.out.print("Instructor's email: ");
		System.out.println(email);
	}
}
