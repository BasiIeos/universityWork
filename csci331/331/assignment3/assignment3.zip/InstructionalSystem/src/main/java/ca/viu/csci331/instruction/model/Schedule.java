package main.java.ca.viu.csci331.instruction.model;

public class Schedule
{
	private String day = new String();
	private int hour;
	private int minute;
	private int duration;
	private String location = new String();
	
	public Schedule()
	{
	}
	
	public Schedule(String da, int h, int m, int d, String l)
	{
		day = da;
		hour = h;
		minute = m;
		duration = d;
		location = l;
	}
	
	public String getDay()
	{
		return day;
	}
	
	public int getHour()
	{
		return hour;
	}
	
	public int getMinute()
	{
		return minute;
	}
	
	public int getDur()
	{
		return duration;
	}
	
	public String getLoc()
	{
		return location;
	}
	
	public void setDay(String newD)
	{
		day = newD;
	}
	
	public void setHour(int newH)
	{
		hour = newH;
	}
	
	public void setMinute(int newM)
	{
		minute = newM;
	}
	
	public void setDur(int newD)
	{
		duration = newD;
	}
	
	public void setLoc(String newL)
	{
		location = newL;
	}
	
	public void show()
	{
		System.out.print("Day: ");
		System.out.println(day);
		System.out.print("Hour: ");
		System.out.println(hour);
		System.out.print("Minute: ");
		System.out.println(minute);
		System.out.print("Duration: ");
		System.out.println(duration);
		System.out.print("Location: ");
		System.out.println(location);
	}
}
