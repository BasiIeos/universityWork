package test.java.ca.viu.csci331.instruction.services.admission;

public class TestAdmission
{
	
}
