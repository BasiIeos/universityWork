Added duplicate protection in Seminars;
Added enroll, showLiveStud, showAllSemForStud, showCompleteStud, listStudBySem to Enrollments class;
Added StudentService and InstructorService classes;
Added checkIns, listIns, listIns2 to Seminars class;
Added getIns to Seminar class;
Added complete variable, complete, isComplete functions to Enrollment class;