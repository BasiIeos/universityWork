package main.java.viu.csci331.instruction.services.instructor;

import main.java.ca.viu.csci331.instruction.model.*;
import java.util.*;

public class InstructorService
{
	private final int INF = 999999998;
	private Instructors ins = new Instructors(INF);
	private Seminars sem = new Seminars(INF);
	private Enrollments enr = new Enrollments(INF);
	
	public void showSem(String insID)
	{
		Instructor i = ins.searchByID(insID);
		sem.checkIns(i);
	}
	
	// aren't we supposed to make the timetable from the list of seminars at the user interaction level? 
	// here's the full list of seminars then
	public Seminars allSem(String insID)
	{
		Instructor i = ins.searchByID(insID);
		return sem.listIns(i);
	}
	
	public void setGrade(String studID, double g)
	{
		enr.setGrade(studID, g);
	}
	
	public void listStudBySem(String insID)
	{
		Instructor i = ins.searchByID(insID);
		LinkedList <Seminar> newSem = sem.listIns2(i);
		enr.listStudBySem(newSem);
	}
}
