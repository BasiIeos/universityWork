package main.java.ca.viu.csci331.instruction.model;

import java.util.*;

public class Enrollments
{
	private LinkedList <Enrollment> enrollments = new LinkedList <Enrollment> ();
	private final int capacity;
	private int numberOfEnrollments;
	
	public Enrollments(int cap)
	{
		capacity = cap;
		numberOfEnrollments = 0;
	}
	
	public void enroll(Enrollment newE)
	{
		if (numberOfEnrollments == capacity)
		{
			System.out.println("Error: Enrollments database is at it's capacity, please try again later\n");
		}
		else
		{
			enrollments.add(newE);
			numberOfEnrollments++;
		}
	}
	
	public void cancel(Enrollment e)
	{
		if (enrollments.contains(e))
		{
			int i = enrollments.indexOf(e);
			enrollments.remove(i);
			numberOfEnrollments--;
		}
		else
		{
			System.out.println("Error: no such enrollment found. Please check your data and try again\n");
		}
	}
	
	public void show()
	{
		Enrollment temp = new Enrollment();
		System.out.println("All enrollments:\n");
		for (int i = 0; i < numberOfEnrollments; i++)
		{
			temp = enrollments.get(i);
			System.out.print(i);
			System.out.println(":");
			temp.show();
		}
	}
	
	public void setGrade(String studID, double g)
	{
		boolean c = false;
		for (int i = 0; ((i < numberOfEnrollments) && (!c)); i++)
		{
			if (enrollments.get(i).getStud().getID() == studID)
			{
				enrollments.get(i).setGrade(g);
			}
		}
	}
	
	public void showLiveStud(Student stud)
	{
		for (int i = 0; i < numberOfEnrollments; i++)
		{
			if ((enrollments.get(i).getStud() == stud) && (!enrollments.get(i).isComplete()))
				enrollments.get(i).show();
		}
	}
	
	public Seminars showAllSemForStud(Student stud)
	{
		Seminars sem = new Seminars(999999998);
		for (int i = 0; i < numberOfEnrollments; i++)
		{
			if ((enrollments.get(i).getStud() == stud) && (!enrollments.get(i).isComplete()))
			{
				sem.add(enrollments.get(i).getSem());
			}
		}
		return sem;
	}
	
	public void showCompleteStud(Student stud)
	{
		for (int i = 0; i < numberOfEnrollments; i++)
		{
			if ((enrollments.get(i).getStud() == stud) && (enrollments.get(i).isComplete()))
				enrollments.get(i).show();
		}
	}
	
	public void listStudBySem(LinkedList <Seminar> sem)
	{
		for (int j = 0; j < sem.size(); j++)
		{
			System.out.println("Seminar:");
			sem.get(j).show();
			System.out.println("Students:");
			for (int i = 0; i < numberOfEnrollments; i++)
			{
				if ((enrollments.get(i).getSem() == sem.get(j)) && (!enrollments.get(i).isComplete()))
				{
					enrollments.get(i).getStud().show();
				}
			}
		}
	}
}
