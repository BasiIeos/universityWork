package main.java.viu.csci331.instruction.services.student;

import main.java.ca.viu.csci331.instruction.model.*;

public class StudentService
{
	private final int INF = 999999998;
	private AdmittedStudents stud = new AdmittedStudents(INF);
	private Enrollments enr = new Enrollments(INF);
	
	public void enroll(String studID, Seminar sem)
	{
		Enrollment e = new Enrollment(stud.searchByID(studID), sem);
		enr.enroll(e);
	}
	
	public void showLiveSem(String studID)
	{
		enr.showLiveStud(stud.searchByID(studID));
	}
	
	// aren't we supposed to make the timetable from the list of seminars at the user interaction level? 
	// here's the full list of live seminars then
	public Seminars allSem(String studID)
	{
		return enr.showAllSemForStud(stud.searchByID(studID));
	}
	
	public void showCompleteSem(String studID)
	{
		enr.showCompleteStud(stud.searchByID(studID));
	}
}
