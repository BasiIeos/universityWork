package test.java.ca.viu.csci331.instruction.services.instructor;

public class TestInstructorService
{

}
