package test.java.ca.viu.csci331.instruction.services.administration;

public class TestAdministration
{

}