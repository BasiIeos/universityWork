package test.java.ca.viu.csci331.instruction.retrieval.admission;

public class TestRetrievalOfAdmission
{

}
