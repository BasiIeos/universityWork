package ca.viu.csci331.lab1;

public class Greet
{
	private String text;
	
	public Greet()
	{
		text = "";
	}
	public Greet(String s)
	{
		text = s;
	}
	public void setText(String s)
	{
		text = s;
	}
	public String getText()
	{
		return text;
	}
}
