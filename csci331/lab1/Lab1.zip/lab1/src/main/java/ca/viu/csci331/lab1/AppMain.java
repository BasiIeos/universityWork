package ca.viu.csci331.lab1;

public class AppMain
{
	public static void main(String args[])
	{
		Greet greeting = new Greet("Hello world");
		System.out.println(greeting.getText());
	}
}
