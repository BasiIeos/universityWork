package ca.viu.csci331.lab1;

import org.junit.Test;
import org.junit.Assert;

public class GreetTests
{
	@Test
	public void testSetandGet()
	{
		String text = "Hello world";
		Greet greeting = new Greet();
		greeting.setText(text);
		Assert.assertTrue(text.equals(greeting.getText()));
	}
}
